library('testthat')
library('StratoBayes')

suppressPackageStartupMessages(test_check("StratoBayes"))
