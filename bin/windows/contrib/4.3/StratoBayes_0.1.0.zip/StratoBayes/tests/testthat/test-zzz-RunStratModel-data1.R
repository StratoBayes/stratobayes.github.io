test_that("data set 1 can be aligned using default settings", {
  skip_on_cran() # slow
  set.seed(1)

  stratModel1t <- StratModel(stratData = stratData1,
                             priors = stratPrior1,
                             alignmentScale = "height",
                             sedModel = "site",
                             alphaPosition = "bottom",
                             nKnots = 10,
                             overlapPenalty = TRUE,
                             sigmaFixed = TRUE)

  stratMCMC1t <- StratMCMC(stratModel = stratModel1t,
                           nIter = 300,
                           nChains = 8,
                           nThin = 5)


  r1 <- RunStratModel(stratObject = stratData1,
                      stratModel = stratModel1t,
                      stratMCMC = stratMCMC1t,
                      nRun = 2,
                      runParallel = requireNamespace("doParallel", quietly = TRUE),
                      visualise = FALSE,
                      seed = 1:2)

  if (interactive()) {
    # plot(r1, alignment = "all")
    TracePlot(r1, alignment = "all", parameters = c(1, 2, "posterior"))
  }

  estimates <- summary(r1)

  nAln <- estimates[[c("general", "overallAlignments")]]
  correctAlignments <-
    abs(vapply(
      seq_len(nAln),
      function(a) estimates[[a]][["summary"]]["alpha_site_2", "mean"],
      numeric(1)
    ) - 6.3) < 1 &
      abs(vapply(
        seq_len(nAln),
        function(a) estimates[[a]][["summary"]]["alpha_site_3", "mean"],
        numeric(1)) - 1.8) < 1


  # at least one correct alignment:
  expect_gte(sum(correctAlignments), 1)

})
