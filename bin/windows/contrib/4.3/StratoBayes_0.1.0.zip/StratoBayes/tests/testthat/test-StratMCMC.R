test_that("StratMCMC methods work", {
  expect_snapshot(print(stratMCMC1))

  expect_equal(.PrettyNumber(NULL), numeric(0))
  expect_equal(.PrettyNumber(1 / 3), 0.333)
  expect_snapshot(summary(stratMCMC1))

  # print mcmc from run with completed iterations
  stratMCMC1$completedIter <- 100
  expect_snapshot(print(stratMCMC1))

  # check that summary.StratMCMC produces valid output
  output <- utils::capture.output(summary.StratMCMC(stratMCMC1))
  expect_true(any(grepl("MCMC settings", output[[1]])))
  expect_true(any(grepl("Probability", output[[4]])))
  expect_true(any(grepl("MCMC settings", output[[1]])))
  expect_true(any(grepl("Multivariate", output[[6]])))
  expect_true(any(grepl("4", output[[6]])))

})
