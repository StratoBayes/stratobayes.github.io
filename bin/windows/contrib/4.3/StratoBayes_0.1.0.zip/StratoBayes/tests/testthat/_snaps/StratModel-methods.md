# StratModel() methods work

    Code
      summary(stratModel2)
    Output
      Stratigraphic model with 7 age-height parameters: 
          alpha_site1, alpha_site2, alpha_site3, gammaLog_site1, gammaLog_site2, gammaLog_site3, gap_site2_1
        Alignment scale: age
        Sedimentation model: site
        Alpha position: 104, 14.92, 0
        Knots for spline: 25

---

    Code
      summary(stratModel3)
    Output
      Stratigraphic model with 4 age-height parameters: 
          alpha_2, gammaLog_3, gammaLog_2, gap_2_1
        Alignment scale: height
        Sedimentation model: partition
        Alpha position: NA, 2.5
        Knots for spline: 10

