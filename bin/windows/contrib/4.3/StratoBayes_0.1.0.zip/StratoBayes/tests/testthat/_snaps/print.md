# print.StratData can print a stratData1

    Code
      print(stratData1)
    Output
      Stratigraphic data comprising 1 signal from 3 sites

# print.StratData can print a stratData2

    Code
      print(stratData2)
    Output
      Stratigraphic data comprising 2 signals from 3 sites

# print.StratModel can print stratModel1

    Code
      print(stratModel1)
    Output
      Stratigraphic model with 4 age-height parameters: 
          alpha_site_2, alpha_site_3, gammaLog_site_2, gammaLog_site_3
        Alignment scale: height
        Sedimentation model: site
        Alpha position: NA, 0, 0
        Knots for spline: 15

# print.StratModel can print stratModel2

    Code
      print(stratModel2)
    Output
      Stratigraphic model with 7 age-height parameters: 
          alpha_site1, alpha_site2, alpha_site3, gammaLog_site1, gammaLog_site2, gammaLog_site3, gap_site2_1
        Alignment scale: age
        Sedimentation model: site
        Alpha position: 104, 14.92, 0
        Knots for spline: 25

# print.StratPosterior can print stratPosterior1

    Code
      print(stratPosterior1)
    Output
      Posterior of stratigraphic model from 3 runs after 5000 iterations:
        Samples: 603 (201 per run)
      
      The model has 4 age-height parameters: 
        alpha_site_2, alpha_site_3, gammaLog_site_2, gammaLog_site_3
      
        Alignment scale: height
        Sedimentation model: site
        Alpha position: NA, 0, 0
        Knots for spline: 15

# print.StratPosterior can print stratPosterior2

    Code
      print(stratPosterior2)
    Output
      Posterior of stratigraphic model from 4 runs after 10000 iterations:
        Samples: 804 (201 per run)
      
      The model has 7 age-height parameters: 
        alpha_site1, alpha_site2, alpha_site3, gammaLog_site1, gammaLog_site2, gammaLog_site3, gap_site2_1
      
        Alignment scale: age
        Sedimentation model: site
        Alpha position: 104, 14.92, 0
        Knots for spline: 25

