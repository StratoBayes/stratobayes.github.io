{ # Initialize test objects

# Don't use parallel evaluation unless doParallel is installed
canRunParallel <- requireNamespace("doParallel", quietly = TRUE)

# Simulate a dataset with two signals
nObs <- 68
depth <- seq(0, 100, length.out = nObs)

# Two signals with different amplitudes
sinSignal <- sin(depth / 10)
gammaSignal <- dgamma(depth, 4, scale = 10) - dgamma(depth, 2, scale = 24)
if (interactive())  {
  plot(sinSignal, col = 2, xlab = "Signal")
  points(gammaSignal * 100, pch = 3, col = 3)
}

set.seed(0) # Stochastic elements of simulation begin here

# Reference section
# Add noise to the true signal values
section1 <- data.frame(
  depth = depth,
  site = "site_1",
  sin = jitter(sinSignal, amount = 0.1),
  gamma = jitter(gammaSignal, amount = 0.001)
)

# Shifted section
# Depth shifted, noise added to true signal values
shift <- 50
stretch <- 2
section2 <- data.frame(
  depth = depth * stretch + shift,
  site = "site_2",
  sin = jitter(sinSignal, amount = 0.1),
  gamma = jitter(gammaSignal, amount = 0.001)
)

# Define a weak but reasonable prior
decentPrior <- structure(
  list(`alpha_site_2` = UniformPrior(min = -300, max = 0),
       `gammaLog_site_2` = NormalPrior(mean = log(stretch) / 2,
                                       sd = 2 * log(2))
       ),
  class = c("StratPrior", "list")
)

if (interactive()) {
  plot(decentPrior, params = 1:2)
}

# Tighter prior that still allows alignment with either sin peak
tightPrior <- structure(list(
  `alpha_site_2` = UniformPrior(min = -150, max = -40),
  `gammaLog_site_2` = NormalPrior(mean = log(stretch), sd = log(2))),
  class = c("StratPrior", "list")
)


# Test that parameter estimates are close to expected values
TestEstimate <- function(estimates, param, expected) {
  estimate <- estimates[[1]][["summary"]][param, ]
  expect_equal(estimate[["mean"]], expected,
               tolerance = estimate[["sd"]] * 8 / abs(estimate[["mean"]]))
}

strat1 <- StratData(rbind(section1, section2),
                    signalColumn = c("sin", "gamma"),
                    zScale = "depth", zColumn = "depth")
}

test_that("Alignment succeeds using just gamma signal", {
  skip_on_cran() # slow
  set.seed(1)

  gamma1 <- StratData(rbind(section1, section2), signalColumn = "gamma",
                      zScale = "depth", zColumn = "depth")

  model <- StratModel(gamma1, priors = tightPrior,
                      alignmentScale = "height", sedModel = "site",
                      alphaPosition = "bottom", nKnots = 15,
                      sigmaFixed = FALSE, aLambda = 1, bLambda = 1000)

  gammaResults <- RunStratModel(
    stratObject = gamma1,
    stratModel = model,
    nRun = 2,
    runParallel = canRunParallel,
    visualise = interactive(),
    nThin = 5,
    nChains = 6,
    nIter = 50,
    seed = 1:2
  )
  estimates <- summary(gammaResults, alignment = "none")

  TestEstimate(estimates, "alpha_site_2", -max(depth))
  TestEstimate(estimates, "gammaLog_site_2", log(stretch))
})

test_that("Alignment succeeds using sin and gamma signals", {
  skip_on_cran() # slow
  set.seed(1)

  model1 <- StratModel(strat1, priors = tightPrior,
                      alignmentScale = "height", sedModel = "site",
                      alphaPosition = "bottom", nKnots = 15,
                      sigmaFixed = FALSE)

  strat1Results <- RunStratModel(
    stratObject = strat1,
    stratModel = model1,
    nRun = 2,
    runParallel = canRunParallel,
    nIter = 50,
    visualise = interactive(),
    nThin = 1,
    nChains = 6,
    seed = 1:2
  )

  estimates <- summary(strat1Results, alignment = "none")
  TestEstimate(estimates, "alpha_site_2", -max(depth))
  TestEstimate(estimates, "gammaLog_site_2", log(stretch))
})

test_that("Alignment succeeds when section lengths differ", {
  skip_on_cran() # slow
  set.seed(1)

  strat2 <- StratData(rbind(section1[seq_len(nObs * 0.8), ], section2),
                      signalColumn = c("sin", "gamma"),
                      zScale = "depth", zColumn = "depth")

  model2 <- StratModel(strat1, priors = tightPrior,
                       alignmentScale = "height", sedModel = "site",
                       alphaPosition = "bottom", nKnots = 15,
                       sigmaFixed = FALSE)

  if (interactive()) {
    plot(strat2)
  }

  strat2ResultsO <- RunStratModel(
    stratObject = strat2,
    stratModel = model2,
    nRun = 2,
    runParallel = canRunParallel,
    nIter = 50,
    visualise = interactive(),
    nThin = 5,
    nChains = 6,
    seed = 1:2
  )

  estimates <- summary(strat2ResultsO, alignment = "none")
  TestEstimate(estimates, "alpha_site_2", -max(depth))
  TestEstimate(estimates, "gammaLog_site_2", log(stretch))
})

test_that("Gamma differentiates equiprobable alignments of sin signal", {
  skip_on_cran() # slow
  set.seed(0)

  strat3 <- StratData(rbind(section1[seq_len(nObs * 0.3), ], section2),
                      signalColumn = c("sin", "gamma"),
                      zScale = "depth", zColumn = "depth")

  model3 <- StratModel(strat1, priors = tightPrior,
                       alignmentScale = "height", sedModel = "site",
                       alphaPosition = "bottom", nKnots = 15,
                       sigmaFixed = FALSE)

  strat3Results <- RunStratModel(
    stratObject = strat3,
    stratModel = model3,
    nRun = 2,
    runParallel = canRunParallel,
    nIter = 200,
    visualise = interactive(),
    nThin = 5,
    nChains = 6,
    seed = 1:2
  )

  estimates <- summary(strat3Results)
  piBy2 <- 10 * pi / 2
  peak <- StratMap(strat3Results, -(stretch * piBy2 + shift), site = 2)
  expect_equal(peak$mean, -piBy2,
               tolerance = abs(peak$sd * 4 / peak$mean))

  ThreePiBy2 <- 10 * 3 * pi / 2
  trough <- StratMap(strat3Results, -(stretch * ThreePiBy2 + shift), site = 2)
  expect_equal(trough$mean, -ThreePiBy2,
               # Less precise as verging on extrapolation
               tolerance = abs(trough$sd * 6 / trough$mean))

})

test_that("Alignment possible with overlapPenalty = FALSE", {
  skip_if(TRUE) # skip in regular testing - test fails with slight changes to the mcmc
  skip_on_cran() # slow
  skip_on_ci() # much slower than preceding tests
  set.seed(0) # Choice of seed important for run time

  # Different section lengths
  strat2 <- StratData(rbind(section1[seq_len(nObs * 0.8), ], section2),
                      signalColumn = c("sin", "gamma"),
                      zScale = "depth", zColumn = "depth")

  model2 <- StratModel(stratData = strat2,
                       priors = decentPrior,
                       alignmentScale = "height",
                       sedModel = "site",
                       alphaPosition = "top",
                       nKnots = 10,
                       overlapPenalty = FALSE)

  if (interactive()) {
    oPar <- par(mfrow = c(2, 2), mar = c(1, 2, 2, 2), xpd = NA)
    plot(strat2, overridePar = FALSE)
    plot(strat2, signal = 2, overridePar = FALSE)
    par(oPar)
  }

  strat2Results <- RunStratModel(
    stratObject = strat2,
    stratModel = model2,
    nRun = 2,
    runParallel = TRUE,
    nIter = 2000,
    visualise = interactive(),
    nThin = 3,
    nChains = 5,
    seed = 1:2
  )

  if (interactive()) {
    summary(strat2Results)
    TracePlot(strat2Results, parameters = 1:2, burnIn = 0)
    legend("topright", legend = c("alpha = 0",
                                  "gammaLog = ", signif(log(stretch), 3)))
    hist(strat2Results, params = 1:2)
    oPar <- par(mfrow = c(2, 2))
    plot(strat2Results, alignment = 1, signal = 1, overridePar = FALSE)
    plot(strat2Results, alignment = 1, signal = 2, overridePar = FALSE)
    plot(strat2Results, alignment = 2, signal = 1, overridePar = FALSE)
    plot(strat2Results, alignment = 2, signal = 2, overridePar = FALSE)
    par(oPar)
  }

  expect_equal(sum(strat2Results$cluster$cluster == 1),
               length(strat2Results$cluster$cluster),
               tolerance = 0.01)
  estimates <- summary(strat2Results)
  TestEstimate(estimates, "alpha_site_2", -max(depth))
  expect_equal(estimates[[1]][["summary"]]["gammaLog_site_2", "mean"],
               log(stretch),
               tolerance = 0.05)
})
