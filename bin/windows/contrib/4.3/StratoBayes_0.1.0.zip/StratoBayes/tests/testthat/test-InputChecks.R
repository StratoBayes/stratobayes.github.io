test_that(".CheckDataFrame() gives errors where necessary", {

  test1 <- NULL
  test2 <- 1:2
  test3 <- data.frame(x = 1:2)
  test4 <- NA
  expect_error(.CheckDataFrame(test1),
               "test1 must be a data frame")
  expect_error(.CheckDataFrame(test2, allowNULL = TRUE),
               "test2 must be a data frame or NULL")
  expect_silent(.CheckDataFrame(test3))
  expect_silent(.CheckDataFrame(test3, allowNULL = TRUE))
  expect_silent(.CheckDataFrame(test1, allowNULL = TRUE))
  expect_error(.CheckDataFrame(test4, allowNULL = TRUE),
               "test4 must be a data frame or NULL")
  }
)

test_that(".CheckDataColumns() gives errors where necessary", {

  test1 <- NULL
  test2 <- 1:2
  test3 <- data.frame(x = 1:2)
  test4 <- NA
  test5 <- data.frame(signal = 1, site = "site1", height = 2)
  test6 <- data.frame(signal = c(NA,NA), site = c(NA, "site1"), height = 1:2)
  expect_error(.CheckDataColumns(test1),
               "test1 must be a data frame")
  expect_error(.CheckDataColumns(test2, columns = "a", allowNULL = TRUE),
               "test2 must be a data frame or NULL")
  expect_error(.CheckDataColumns(test3, columns = "a", allowNULL = TRUE),
               "test3 is missing the following columns: a")
  expect_silent(.CheckDataColumns(test3, columns = "x"))

  expect_error(.CheckDataColumns(test5, columns = c("signal", "depth", "site"),
                                 allowNULL = TRUE),
               "test5 is missing the following columns: depth")

  expect_silent(.CheckDataColumns(test5, columns = c("height","signal", "site"),
                                  allowNULL = TRUE))
  expect_error(.CheckDataColumns(test6, columns = c("height", "signal", "site"),
                     noNA = c("height", "site")),
               "test6 has NA values in the following columns: site")

  }
)


test_that(".MakeNumeric() does its job and gives errors where necessary", {

  test1 <- NULL
  test2 <- 1:2
  test3 <- data.frame(x = 1:2)
  test4 <- NA
  test5 <- data.frame(signal = 1, site = "site1", height = 2)
  test6 <- data.frame(signal = c(NA,1), site = c("site1", 3), height = c(2,"3"),
                      depth = c("site", "depth"))

  expect_error(.MakeNumeric(test1),
               "test1 must be a data frame")
  expect_error(.MakeNumeric(test6, columns =
                              c("signal","site", "depth", "nothing"),
                            allowNULL = TRUE),
               "test6 is missing the following columns: nothing")
  expect_error(.MakeNumeric(test6, columns = c("site", "signal", "depth"),
                            allowNULL = TRUE),
               "The following columns in test6 contain non-NA values that cannot be coerced to numeric: site, depth")
  expect_silent(.MakeNumeric(test6, columns = c("signal")))
  expect_silent(.MakeNumeric(test3, columns = c("x")))
  expect_silent(.MakeNumeric(test6, columns = c("signal"), optionalColumns = "nothing"))
  expect_error(.MakeNumeric(test6, columns = c("signal"), optionalColumns = "depth"),
               "The following columns in test6 contain non-NA values that cannot be coerced to numeric: depth")
}
)

test_that(".CheckTies() does its job and gives errors where necessary", {
  ties1 <- data.frame(height = 1:2,
                              site = 2:3,
                              densityFun = c("dnorm", "dexp"),
                              arg1 = c(0, 1),
                              arg2 = c(1, NA)
  )

  ties2 <- data.frame(height = 1:2,
                                          site = 2:3,
                                          densityFun = c("dnorm", "dexp"),
                                          arg1 = c(0, 1),
                                          arg2 = c(1, NA),
                                          mean = c("N","A")
  )
  ties3 <- data.frame(height = 1:2,
                      site = 2:3,
                      densityFun = c("dnorm", "dexp"),
                      arg1 = c(0, 1),
                      arg2 = c(1, NA),
                      mean = c("N","A"),
                      sd = 1:2
  )
  ties4 <- data.frame(height = c("n","p"),
                      site = 2:3,
                      densityFun = c("dnorm", "dexp"),
                      arg1 = c(0, 1),
                      arg2 = c(1, NA),
                      mean = c("N","A"),
                      sd = 1:2
  )
  ties5 <- data.frame(height = 2:1,
                      site = 2:3,
                      mean = c(1, "3"),
                      sd = 1:2
  )
  ties6 <- data.frame(height = 2:1,
                      site = 2:3,
                      densityFun = c(1, "3"),
                      sd = 1:2
  )

  ties7 <- data.frame(height = 2:1,
                      site = 2:3,
                      densityFun = c("dnorm", "dnorm"),
                      sd = 1:2,
                      mean = c(NA,1)
  )

  ties8 <- data.frame(height = 2:1,
                      site = 2:3,
                      densityFun = c("dnorm", NA),
                      arg1 = 1:2,
                      arg2 = 1:2)

  ties9 <- data.frame(height = 2:1,
                      site = 2:3,
                      densityFun = c("dnorm", "dnorm"),
                      arg1 = c(NA,2),
                      arg2 = 1:2)


  ties10 <- data.frame(height = 2:1,
                      site = 2:3,
                      densityFun = c("dexp", "dunif"),
                      arg1 = c(1,2))

  ties11 <- data.frame(height = 2:1,
                       site = 2:3,
                       densityFun = c("dexp", "dunif"),
                       arg1 = c(1,2),
                       arg2 = c(1,NA))

  ties12 <- data.frame(height = 2:1,
                       site = 2:3,
                       densityFun = c("dexp", "dunif"),
                       arg1 = c(1,2),
                       arg3 = c(1,3))

expect_silent(.CheckTies(ties1, "height"))
expect_silent(.CheckTies(ties2, "height"))
expect_error(.CheckTies(ties3, "height"),
             "The following columns in ties contain non-NA values that cannot be coerced to numeric: mean")
expect_error(.CheckTies(ties4, "height"),
             "The following columns in ties contain non-NA values that cannot be coerced to numeric: height, mean")
expect_silent(.CheckTies(ties5, "height"))
expect_error(.CheckTies(ties6, "height"),
             "ties must have either 'mean' and 'sd' columns or 'densityFun' and 'arg1' columns.")
expect_error(.CheckTies(ties7, "height"),
             "Row 1 in ties is missing")
expect_error(.CheckTies(ties8, "height"),
             "Row 2 in ties is missing")
expect_error(.CheckTies(ties9, "height"),
             "Row 1 in ties is missing")
expect_error(.CheckTies(ties10, "height"),
             "dunif, specified in ties, requires more arguments")
expect_error(.CheckTies(ties11, "height"),
             "for dunif, specified in ties, arg2 cannot be NA")
expect_error(.CheckTies(ties12, "height"),
             "arg2 is missing")

expect_silent(.CheckTies(NULL, "height"))

}
)
