test_that(".ValidateAlignment() works", {
  expect_equal(.ValidateAlignment("all", 1:2), 1:2)
  expect_equal(.ValidateAlignment("ALL",0:2), 0:2)
  expect_equal(.ValidateAlignment("none",2:4), 2:4)
  expect_equal(.ValidateAlignment(1:2,0:3), 1:2)
  expect_equal(.ValidateAlignment(2,0:3), 2)
  expect_equal(.ValidateAlignment(1,1), 1)

  expect_error(.ValidateAlignment(NULL, 1), "cannot be NULL")
  expect_error(.ValidateAlignment("fail",1), "`alignment` must be")
  expect_error(.ValidateAlignment(1), "clustUnique")
  expect_error(.ValidateAlignment(1:2,2:4), "must consist of whole")
})

test_that(".ValidateParams() succeeds", {
  expect <- as.data.frame(matrix(1:2, nrow = 1), optional = TRUE)
  expect_equal(.ValidateParams(NULL, 1, "NULL"), "NULL")
  expect_equal(.ValidateParams(1:2, 2), expect)
  expect_error(.ValidateParams(1:2, 3), "vector of length 3")
  mat6 <- matrix(1:6, 3, 2)
  expect6 <- as.data.frame(mat6, optional = TRUE)
  expect_equal(.ValidateParams(mat6, 2), expect6)
  expect_error(.ValidateParams(mat6, 3), "vector of length 3")
  expect_equal(.ValidateParams(expect6, 2), expect6)
  expect_error(.ValidateParams(expect6, 3), "vector of length 3")
})

test_that(".ValidateModelParams works", {

  expect_error(.ValidateModelParams("", stratPosterior1),
               "parameters must be atomic")

  expect_error(.ValidateModelParams(stratModel1, 1),
               "object needs to be of class")

  expect_error(.ValidateModelParams(stratPosterior1, ""),
               "`parameters` may not be empty")

  expect_error(.ValidateModelParams(stratPosterior1, "sigma"),
               "Invalid names specified for parameters")

  expect_error(.ValidateModelParams(stratPosterior1, 5),
               "Invalid number '5' specified for `parameters`")

  expect_equal(.ValidateModelParams(stratPosterior1, "probability"),
               c("posterior", "prior_parameters", "prior_overlap",
                 "likelihood_spline"))

  expect_equal(.ValidateModelParams(stratPosterior1, "log posterior"),
               "posterior")

  expect_equal(.ValidateModelParams(stratPosterior1, "log prior_parameters"),
               "prior_parameters")

  expect_equal(.ValidateModelParams(stratPosterior1, "log prior_overlap"),
               "prior_overlap")

  expect_equal(.ValidateModelParams(stratPosterior1, "log likelihood_spline"),
               "likelihood_spline")

  expect_equal(.ValidateModelParams(stratPosterior2, "log likelihood_ties"),
               "likelihood_ties")

  expect_equal(.ValidateModelParams(stratPosterior1, "log likelihood"),
               "likelihood")

  expect_equal(.ValidateModelParams(stratPosterior1, "log prior"),
               "prior")

  expect_equal(.ValidateModelParams(stratPosterior1, "beta")[5:6],
               c("beta_value_5", "beta_value_6"))

  expect_equal(.ValidateModelParams(stratPosterior2, "beta_b")[1:3],
               c("beta_b_1", "beta_b_2", "beta_b_3"))

})
