test_that("ClusteringFunctions work", {
  test <- cbind(c(runif(20), runif(30, 2, 4)),
                c(rnorm(20), rnorm(30, 10, 0.5)))
  expect_equal(.PamCluster(test, 10, 0, 0),
               .ProtoCluster(test, 10, 0, 0))
})

test_that("pamSils 0.6 cutoff works", {
  test <- cbind(runif(30, 2, 4), rnorm(30, 10, 0.5))
  expect_equal(.PamCluster(test, 10, 0.6),
               .ProtoCluster(test, 10, 0.6))
})

test_that(".myNrow works", {
  test <- cbind(runif(30, 2, 4), rnorm(30, 10, 0.5))
  expect_equal(.myNrow(test), nrow(test))
  test2 <- 1:2
  expect_equal(.myNrow(test2), length(test2))
})
