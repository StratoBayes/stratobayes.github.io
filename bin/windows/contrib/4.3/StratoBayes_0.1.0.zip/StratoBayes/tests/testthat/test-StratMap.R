test_that("StratMap works", {

expect_error(StratMap(1, 2, 2), "stratObject needs to be")

expect_equal(as.numeric(StratMap(stratPosterior1, 2, 2)),
             c(2, 10.3, 0.5, 9.7, 10.3, 11.6), tolerance = 0.1)

expect_s3_class(StratMap(stratPosterior3, 2, 2), "data.frame")

})

test_that("StratMap works with prior", {
  set.seed(1)
  h1 <- StratMap(stratModel1, heights = 0, site = 2, stratData = stratData1)
  expect_equal(h1$mean, mean(unlist(stratModel1$priors$metro$alpha_site_2$args)), tolerance = 0.5)
  })

test_that("StratMap works with new cluster object and
          iterations before burnIn", {
            clustNew <- Cluster(stratPosterior2, iterations = 3500:4000)
            expect_true(
              StratMap(stratPosterior2,
                             heights = 1,
                             site = 3,
                                      stratCluster = clustNew,
                                      alignment = 1)[ , "sd"]
              <
                StratMap(stratPosterior2,
                         heights = 1,
                         site = 3,
                         stratCluster = clustNew,
                         alignment = "all")[ , "sd"]

             )
          })
