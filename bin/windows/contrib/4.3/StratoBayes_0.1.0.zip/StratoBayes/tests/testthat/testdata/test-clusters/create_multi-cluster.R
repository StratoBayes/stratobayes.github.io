library("StratoBayes")
set.seed(1)
nObs <- 68
depth <- seq(0, 100, length.out = nObs)

# Two signals with different amplitudes
signal1 <- sin(depth / 10)
signal2 <- dgamma(depth, 4, scale = 10) - dgamma(depth, 2, scale = 24)
if (interactive())  {
  plot(signal1 ~ depth, col = 2, xlab = "Depth", ylab = "Signal")
  abline(v = 10 * c(1, 5) * pi / 2, lty = "dotted")
  points(signal2 * 100 ~ depth, pch = 3, col = 3)
}

# Test alignment with all data
section1 <- data.frame(
  depth = depth,
  site = "site_1",
  sin = jitter(signal1),
  gamma = jitter(signal2)
)
shift <- 50
stretch <- 2
section2 <- data.frame(
  depth = depth * stretch + shift,
  site = "site_2",
  sin = jitter(signal1),
  gamma = jitter(signal2)
)

decentPrior <- structure(list(
  `alpha_site_2` = UniformPrior(min = -300, max = 0),
  `gammaLog_site_2` = NormalPrior(mean = log(stretch) / 2, sd = 2 * log(2))),
  class = c("list", "StratPrior"))

# We could do this by gamma; does it still work if we add sin?
strat1 <- StratData(rbind(section1, section2),
                    signalColumn = c("sin", "gamma"),
                    zColumn = "depth", zScale = "depth")


multiClusterPost <- RunStratModel(
  stratObject = strat1,
  nRun = 2,
  runParallel = FALSE,
  alignmentScale = "height",
  sedModel = "site",
  # We want to recover multiple alignments, for tests.
  # So we don't want this to converge perfectly; keep nIter lowish
  nIter = 250,
  visualise = FALSE,
  nThin = 10,
  nChains = 6,
  priors = decentPrior,
  nKnots = 15
)

if(interactive()) {
  oPar <- par(mfrow = c(2, 2))
  plot(multiClusterPost, overridePar = FALSE, separateSites = FALSE)
  plot(multiClusterPost, signal = "gamma", overridePar = FALSE, separateSites = FALSE)
  hist(multiClusterPost, overridePar = FALSE)
  ScatterPlot(multiClusterPost, overridePar = FALSE)
  par(oPar)
}

saveRDS(multiClusterPost,
        testthat::test_path("testdata", "test-clusters",
                            "test-multi-cluster.rds"))
