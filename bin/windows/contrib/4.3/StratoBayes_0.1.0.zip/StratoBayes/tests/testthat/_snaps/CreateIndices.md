# Create indices works with multi gap-names-3-sites

    Code
      .CreateIndices(tmulti, alignmentScale = "height", sedModel = "s",
        alphaPosition = "bottom")
    Output
      $alpha
      [1] 1 2
      
      $gamma
      [1] 3 4
      
      $rates
      [1] 3 4
      
      $gap
      [1] 5
      
      $gapInd
           [,1] [,2] [,3]
      [1,]   NA   NA   NA
      [2,]   NA   NA   NA
      [3,]   NA    1   NA
      [4,]   NA   NA   NA
      
      $names
      [1] "alpha_site2"    "alpha_site3"    "gammaLog_site2" "gammaLog_site3"
      [5] "gap_site2_1"   
      
      $ageHeightSign
      [1] 1
      
      $alignmentScale
      [1] "height"
      
      $sedModel
      [1] "site"
      
      $alphaPosition
      [1]        NA -1.168179  0.000000
      
      $depthHeightSign
      [1] 1
      

---

    Code
      .CreateIndices(tmulti, alignmentScale = "height", sedModel = "p",
        alphaPosition = "bottom")
    Output
      $alpha
      [1] 1 2
      
      $gamma
      [1] 3 4 5
      
      $rates
      [1] 3 4 5
      
      $gap
      [1] 6
      
      $gapInd
           [,1] [,2] [,3]
      [1,]   NA   NA   NA
      [2,]   NA   NA   NA
      [3,]   NA    1   NA
      [4,]   NA   NA   NA
      
      $names
      [1] "alpha_site2"       "alpha_site3"       "gammaLog_part 2.1"
      [4] "gammaLog_part 2.2" "gammaLog_part 3.1" "gap_site2_1"      
      
      $ageHeightSign
      [1] 1
      
      $alignmentScale
      [1] "height"
      
      $sedModel
      [1] "partition"
      
      $alphaPosition
      [1]        NA -1.168179  0.000000
      
      $depthHeightSign
      [1] 1
      

---

    Code
      .CreateIndices(tmulti, alignmentScale = "height", sedModel = "s x p",
        alphaPosition = "bottom")
    Output
      $alpha
      [1] 1 2
      
      $gamma
      [1] 3 4 5
      
      $zeta
      [1] 6
      
      $rates
      [1] 3 4 5 6
      
      $gap
      [1] 7
      
      $gapInd
           [,1] [,2] [,3]
      [1,]   NA   NA   NA
      [2,]   NA   NA   NA
      [3,]   NA    1   NA
      [4,]   NA   NA   NA
      
      $names
      [1] "alpha_site2"       "alpha_site3"       "gammaLog_part 2.1"
      [4] "gammaLog_part 2.2" "gammaLog_part 3.1" "zetaLog_site3"    
      [7] "gap_site2_1"      
      
      $ageHeightSign
      [1] 1
      
      $alignmentScale
      [1] "height"
      
      $sedModel
      [1] "site x partition"
      
      $alphaPosition
      [1]        NA -1.168179  0.000000
      
      $depthHeightSign
      [1] 1
      

---

    Code
      .CreateIndices(tmulti, alignmentScale = "height", sedModel = "s, p",
        alphaPosition = "bottom")
    Output
      $alpha
      [1] 1 2
      
      $gamma
      [1] 3 4 5
      
      $rates
      [1] 3 4 5
      
      $gap
      [1] 6
      
      $gammaInd
           [,1] [,2] [,3]
      [1,]   NA    1    3
      [2,]   NA    2   NA
      [3,]   NA   NA   NA
      [4,]   NA    2   NA
      
      $gapInd
           [,1] [,2] [,3]
      [1,]   NA   NA   NA
      [2,]   NA   NA   NA
      [3,]   NA    1   NA
      [4,]   NA   NA   NA
      
      $names
      [1] "alpha_site2"             "alpha_site3"            
      [3] "gammaLog_part 2.1_site2" "gammaLog_part 2.2_site2"
      [5] "gammaLog_part 3.1_site3" "gap_site2_1"            
      
      $ageHeightSign
      [1] 1
      
      $alignmentScale
      [1] "height"
      
      $sedModel
      [1] "site, partition"
      
      $alphaPosition
      [1]        NA -1.168179  0.000000
      
      $depthHeightSign
      [1] 1
      

---

    Code
      .CreateIndices(tmulti, alignmentScale = "age", sedModel = "s", alphaPosition = "b")
    Output
      $alpha
      [1] 1 2 3
      
      $gamma
      [1] 4 5 6
      
      $rates
      [1] 4 5 6
      
      $gap
      [1] 7
      
      $gapInd
           [,1] [,2] [,3]
      [1,]   NA   NA   NA
      [2,]   NA   NA   NA
      [3,]   NA    1   NA
      [4,]   NA   NA   NA
      
      $names
      [1] "alpha_site1"    "alpha_site2"    "alpha_site3"    "gammaLog_site1"
      [5] "gammaLog_site2" "gammaLog_site3" "gap_site2_1"   
      
      $ageHeightSign
      [1] -1
      
      $alignmentScale
      [1] "age"
      
      $sedModel
      [1] "site"
      
      $alphaPosition
      [1]  1.000000 -1.168179  0.000000
      
      $depthHeightSign
      [1] 1
      

---

    Code
      .CreateIndices(tmulti, alignmentScale = "age", sedModel = "p", alphaPosition = "b")
    Output
      $alpha
      [1] 1 2 3
      
      $gamma
      [1] 4 5 6 7
      
      $rates
      [1] 4 5 6 7
      
      $gap
      [1] 8
      
      $gapInd
           [,1] [,2] [,3]
      [1,]   NA   NA   NA
      [2,]   NA   NA   NA
      [3,]   NA    1   NA
      [4,]   NA   NA   NA
      
      $names
      [1] "alpha_site1"       "alpha_site2"       "alpha_site3"      
      [4] "gammaLog_part 1.1" "gammaLog_part 2.1" "gammaLog_part 2.2"
      [7] "gammaLog_part 3.1" "gap_site2_1"      
      
      $ageHeightSign
      [1] -1
      
      $alignmentScale
      [1] "age"
      
      $sedModel
      [1] "partition"
      
      $alphaPosition
      [1]  1.000000 -1.168179  0.000000
      
      $depthHeightSign
      [1] 1
      

---

    Code
      .CreateIndices(tmulti, alignmentScale = "age", sedModel = "s x p",
        alphaPosition = "b")
    Output
      $alpha
      [1] 1 2 3
      
      $gamma
      [1] 4 5 6 7
      
      $zeta
      [1] 8 9
      
      $gap
      [1] 10
      
      $rates
      [1] 4 5 6 7 8 9
      
      $gapInd
           [,1] [,2] [,3]
      [1,]   NA   NA   NA
      [2,]   NA   NA   NA
      [3,]   NA    1   NA
      [4,]   NA   NA   NA
      
      $names
       [1] "alpha_site1"       "alpha_site2"       "alpha_site3"      
       [4] "gammaLog_part 1.1" "gammaLog_part 2.1" "gammaLog_part 2.2"
       [7] "gammaLog_part 3.1" "zetaLog_site2"     "zetaLog_site3"    
      [10] "gap_site2_1"      
      
      $ageHeightSign
      [1] -1
      
      $alignmentScale
      [1] "age"
      
      $sedModel
      [1] "site x partition"
      
      $alphaPosition
      [1]  1.000000 -1.168179  0.000000
      
      $depthHeightSign
      [1] 1
      

---

    Code
      .CreateIndices(tmulti, alignmentScale = "age", sedModel = "s, p",
        alphaPosition = "b")
    Output
      $alpha
      [1] 1 2 3
      
      $gamma
      [1] 4 5 6 7
      
      $gap
      [1] 8
      
      $rates
      [1] 4 5 6 7
      
      $gammaInd
           [,1] [,2] [,3]
      [1,]    1    2    4
      [2,]   NA    3   NA
      [3,]   NA   NA   NA
      [4,]   NA    3   NA
      
      $gapInd
           [,1] [,2] [,3]
      [1,]   NA   NA   NA
      [2,]   NA   NA   NA
      [3,]   NA    1   NA
      [4,]   NA   NA   NA
      
      $names
      [1] "alpha_site1"             "alpha_site2"            
      [3] "alpha_site3"             "gammaLog_part 1.1_site1"
      [5] "gammaLog_part 2.1_site2" "gammaLog_part 2.2_site2"
      [7] "gammaLog_part 3.1_site3" "gap_site2_1"            
      
      $ageHeightSign
      [1] -1
      
      $alignmentScale
      [1] "age"
      
      $sedModel
      [1] "site, partition"
      
      $alphaPosition
      [1]  1.000000 -1.168179  0.000000
      
      $depthHeightSign
      [1] 1
      

