# StratModel creation works with StratData 1

    Code
      StratModel(stratData = stratData1, priors = priors, alignmentScale = "height",
        sedModel = "site", alphaPosition = "middle", nKnots = 25)
    Output
      Stratigraphic model with 4 age-height parameters: 
          alpha_site_2, alpha_site_3, gammaLog_site_2, gammaLog_site_3
        Alignment scale: height
        Sedimentation model: site
        Alpha position: NA, 1.09, 2.23
        Knots for spline: 25

# StratModel creation works with StratData 2

    Code
      StratModel(stratData = stratData2, priors = priors, alignmentScale = "height",
        sedModel = "site x partition", alphaPosition = "middle", nKnots = 25)
    Output
      Stratigraphic model with 7 age-height parameters: 
          alpha_site2, alpha_site3, gammaLog_part 2.1, gammaLog_part 2.2, gammaLog_part 3.1, zetaLog_site3, gap_site2_1
        Alignment scale: height
        Sedimentation model: site x partition
        Alpha position: NA, 14.92, 10
        Knots for spline: 25

