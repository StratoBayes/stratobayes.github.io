{ # Initialize test objects
  set.seed(0)
  testDataMulti <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  testDataMulti[[c("parts", "Hight")]] <- c(80.0, 10.5, 20.0, 20.0, 31, 20)
  tmulti <- StratData(testDataMulti[["signal"]], parts = testDataMulti[["parts"]],
                      ties = testDataMulti[["ties"]],
                      signalColumn = c("a", "b"), zColumn = "Hight",
                      siteColumn = "SIT")
  #StratModelTemplate(tmulti, alignmentScale = "age", sedModel = "s", alphaPosition = "b")
  priorsm <- structure(list(
      "alpha_site1" = UniformPrior(min  = 35, max  = 45),
      "alpha_site2" = UniformPrior(min  = 30, max  = 40),
      "alpha_site3" = UniformPrior(min  = 30, max  = 40),
      "gammaLog_site1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_site2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_site3" = NormalPrior(mean  = 1, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.5)),
      class = c("list", "StratPrior"))

  modelm <- StratModel(tmulti, priorsm, alignmentScale = "age", sedModel = "site",
                       alphaPosition = "bottom")
  mcmcm <- StratMCMC(modelm, nIter = 10, nChains = 2)
}

test_that("RunStratModel throws appropriate errors for invalid input", {

  expect_error(RunStratModel(1),
               "'StratData' or 'StratPosterior' object",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = 1, alignmentScale = "age",
                             sedModel = "site", alphaPosition = "bottom"),
               "`priors` must be an object of class 'StratPrior'",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,stratModel = NA),
               "`StratModel` must be `NULL`, or an object of class 'StratModel'",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, stratModel = modelm, stratMCMC = FALSE),
               "`stratMCMC` must be `NULL`, or an object of class 'StratMCMC'",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,priors = priorsm, alignmentScale = 1),
               "`alignmentScale` must be either 'height' or 'age'",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,priors = priorsm, alignmentScale = "age", sedModel = NA),
               "Invalid 'sedModel' input. Please choose from 'site', 'partition', 'site x partition', or 'site, partition'.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,priors = priorsm, alignmentScale = "age", sedModel = "s",
                             nKnots = 1.1),
               "'nKnots' must be an integer >= 2.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             overlapPenalty = "no"),
               "Invalid `overlapPenalty`",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             overlapPenalty =  1),
               "Invalid `overlapPenalty`",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             sigmaFixed =  c(1,NA)),
               "'sigmaFixed' must not contain NA values.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             sigmaFixed =  c(1)),
               "'sigmaFixed' needs to be of length 2.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             sigmaFixed =  "no"),
               "'sigmaFixed' needs to be numeric.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             flexibleKnots =  0),
               "'flexibleKnots' needs to be logical.",
               fixed = TRUE)



  expect_error(RunStratModel(tmulti,priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             knotRange = c(NA,50), flexibleKnots = FALSE),
               "'knotRange' must not contain NA values.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti,priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             knotRange = c(0,Inf), flexibleKnots = FALSE),
               "'knotRange' needs to be finite.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             countGaps = NA),
               "'countGaps' needs to be logical.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             aLambda = NA),
               "aLambda must be numeric",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             bSigma = "wrong"),
               "bSigma must be numeric.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             minSignalOverlap = TRUE),
               "minSignalOverlap needs to be an integer or FALSE",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             priorsProposals  = TRUE),
               "`priorsProposals` must be an object of class 'StratPrior'",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             ratesRange  = 1),
               "'ratesRange' needs to be of length 2.",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             parametersInitial = c(1)),
               "parametersInitial",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             parametersInitial = c(rep(c("a", rep(1,6))))),
               "parametersInitial",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             parametersInitial = c(rep(-1,7))),
               "parametersInitial",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             colourScale = "dark"),
               "Invalid colourScale",
               fixed = TRUE)

  expect_error(RunStratModel(tmulti, priors = priorsm,
                             alignmentScale = "age", sedModel = "s",
                             nIter = 1:2),
               "`nIter`",
               fixed = TRUE)
})



test_that("RunStratModel throws warnings when overwriting arguments", {
  expect_warning(
    r1 <- RunStratModel(stratObject = stratData1,
                        stratModel = stratModel1,
                        sigmaFixed = FALSE,
                        priors = FALSE,
                        alignmentScale = "age", sedModel = "s",
                        visualise = FALSE, runParallel = FALSE,
                        nIter = 1, saveChains = 1:2, nRun = 1),
    regexp = "priors|alignmentScale|sedModel|sigmaFixed"
  )
  expect_s3_class(r1, "StratPosterior")

  stratMCMC1b <- StratMCMC(stratModel1, nIter = 3, nChains = 2)
  expect_warning(
    r2 <- RunStratModel(stratObject = stratData1,
                        stratModel = stratModel1,
                        stratMCMC = stratMCMC1b,
                        visualise = FALSE, runParallel = FALSE,
                        nIter = 6, saveChains = 1:2, nRun = 1,
                        nChains = 4),
    regexp = "nIter|saveChains|nChains"
  )
  expect_s3_class(r2, "StratPosterior")
})

test_that("RunStratModel warns with duplicated seeds", {
  expect_warning(
    r1 <- RunStratModel(tmulti, priors = priorsm,
                    alignmentScale = "age", sedModel = "s",
                    visualise = FALSE, runParallel = FALSE,
                    nIter = 6, nRun = 5, seed = c(0, 4, 2, 4, 0)),
      "Identical seeds specified \\(4, 0\\); these runs will be identical"
  )
  expect_s3_class(r1, "StratPosterior")
  expect_equal(r1[["samples"]][, , 5, ], r1[["samples"]][, , 1, ])
  expect_equal(r1[["samples"]][, , "run2", ], r1[["samples"]][, , "run4", ])
})


test_that("RunStratModel works with standard settings", {
  r1 <- RunStratModel(tmulti, priors = priorsm,
                      alignmentScale = "age", sedModel = "s",
                      nIter = 2, seed = 0,
                      sigmaFixed = 1:2)
  expect_s3_class(r1, "StratPosterior")
})

test_that("RunStratModel works with fixed knots", {
  r1 <- RunStratModel(tmulti, priors = priorsm,
                      alignmentScale = "age", sedModel = "s",
                      nIter = 1, seed = TRUE,
                      flexibleKnots = FALSE, knotRange = c(20,50),
                      sigmaFixed = 1:2)
  expect_s3_class(r1, "StratPosterior")
})

test_that("RunStratModel works with nRun >1", {
  r1 <- RunStratModel(tmulti, priors = priorsm,
                      alignmentScale = "age", sedModel = "s",
                      nIter = 1, seed = 1:2,
                      nRun = 2, sigmaFixed = 1:2,
                      visualise = FALSE)
  expect_s3_class(r1, "StratPosterior")
})

test_that("RunStratModel works with sigmaFixed = FALSE", {
  r1 <- RunStratModel(tmulti, priors = priorsm,
                      alignmentScale = "age", sedModel = "s",
                      nIter = 1, sigmaFixed = FALSE)
  expect_s3_class(r1, "StratPosterior")
})

test_that("RunStratModel works with sigmaFixed = FALSE & saveMCMC = TRUE", {
  r1 <- RunStratModel(tmulti, priors = priorsm,
                      alignmentScale = "age", sedModel = "s",
                      nIter = 2, sigmaFixed = FALSE,
                      saveMCMC = TRUE)
  expect_s3_class(r1, "StratPosterior")
})

test_that("RunStratModel works with minSignalOverlap = T and overlapPenalty = F", {
  set.seed(0)
  r1 <- RunStratModel(tmulti, priors = priorsm,
                      alignmentScale = "age", sedModel = "s",
                      nIter = 4, minSignalOverlap = 15,
                      overlapPenalty = FALSE, nKnots = 10,
                      nRun = 2)
  expect_s3_class(r1, "StratPosterior")
})

# parallel run
test_that("RunStratModel parallel runs", {
  skip_if_not_installed("doParallel")
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 2, nIter = 2,
                      nChains = 3, visualise = FALSE, seed = 1:2,
                      runParallel = TRUE)
  expect_s3_class(r1, "StratPosterior")
})

# continued run
test_that("RunStratModel continuing runs", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 2, nIter = 2,
                      nChains = 3, visualise = FALSE, seed = 1:2,
                      runParallel = FALSE)
  skip_if_not_installed("doParallel")
  r2 <- RunStratModel(r1, nIter = 3, runParallel = T, visualise = FALSE)
  r3 <- RunStratModel(r2, nIter = 1, visualise = FALSE)
  r4 <- RunStratModel(r3, stratModel = stratModel1, nIter = 6,
                      runParallel = FALSE, nThin = 2, visualise = FALSE)
  expect_s3_class(r4, "StratPosterior")
  expect_equal(r4[["mcmcSummary"]][["saveIter"]][[1]], c(1:6, 8, 10, 12))
})

# continued run with different directory option
test_that("RunStratModel continuing runs - custom directory", {
  tempDir <- tempdir()
  modelDir <- paste0(tempDir, "\\")
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 2, nIter = 2,
                      nChains = 3, visualise = FALSE, seed = 1:2,
                      runParallel = FALSE, modelDir = modelDir,
                      modelName = "testName")
  # continue from directory

  r2 <- RunStratModel(nIter = 1, visualise = FALSE, modelDir = r1$modelDir, modelName = r1$modelName)
  r3 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 2, nIter = 2,
                      nChains = 3, visualise = FALSE, seed = 1:2,
                      runParallel = FALSE, modelDir = tempDir,
                      modelName = "testName")
  # continue from directory

  r4 <- RunStratModel(nIter = 1, visualise = FALSE, modelDir = r3$modelDir, modelName = r3$modelName)
  expect_s3_class(r2, "StratPosterior")
  expect_s3_class(r4, "StratPosterior")
})

# save other chains
test_that("RunStratModel continuing runs", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 2, nIter = 10,
                      nChains = 3, visualise = FALSE, seed = 1:2,
                      runParallel = FALSE, saveChains = c(1, 3))
  # continued
  r2 <- RunStratModel(r1, nIter = 2, runParallel = FALSE, visualise = FALSE,
                      adaptProposal = FALSE)
  expect_s3_class(r2, "StratPosterior")
  expect_equal(dim(r2[["samples"]]), c(length(r2$mcmcSummary$saveIter[[1]]),
                                       length(r2$model$outputParams),
                                       r2$nRun,
                                       length(r2$mcmc$saveChains[[1]])))

  # not continued
  r3 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 2, nIter = 2,
                      nChains = 3, visualise = FALSE, seed = 1:2,
                      runParallel = FALSE, saveChains = c(2,1))

  expect_equal(colnames(r3$samples[,1,1,]), c("chain2", "chain1"))
})


# continued run, mixing adaptation and no adaptation
test_that("RunStratModel changing adaptation", {
  r1 <- RunStratModel(stratData0, stratModel = stratModel0, nRun = 2, nIter = 10,
                      nChains = 3, visualise = FALSE, seed = 1:2,
                      runParallel = FALSE, startAdapting = 4,
                      endAdapting = 10, adaptTemperatures = FALSE)

  r2 <- RunStratModel(r1, nIter = 2, runParallel = FALSE, visualise = FALSE,
                      adaptProposal = FALSE)
  expect_s3_class(r2, "StratPosterior")


  # see that continued run keeps previous saveChains and nChains
  r3 <- RunStratModel(r2, nIter = 2,
                      nKnots = 5, visualise = FALSE, seed = 2:3,
                      runParallel = FALSE, saveChains = c(2, 1), nChains = 4,
                      startAdapting = 1, endAdapting = 2)

  expect_s3_class(r3, "StratPosterior")

})

# continued run, passing MCMC rather than reading from folder
test_that("RunStratModel passing mcmc", {
  r1 <- RunStratModel(stratData0, stratModel = stratModel0, nRun = 2, nIter = 10,
                      nChains = 3, visualise = FALSE, seed = 1:2,
                      runParallel = FALSE, startAdapting = 4,
                      endAdapting = 10, adaptTemperatures = FALSE,
                      modelDir = tempdir(), saveMCMC = TRUE)
  modelDir <- r1$modelDir
  # delete files
  files <- list.files(modelDir, full.names = TRUE, recursive = TRUE,
                      pattern = paste0("^", r1$modelName))
  unlink(files, recursive = TRUE)

  # check that directory is empty
  expect_equal(length(list.files(modelDir, full.names = TRUE, recursive = TRUE,
                                 pattern = paste0("^", r1$modelName))), 0)

  r2 <- RunStratModel(r1, stratMCMC = r1[["mcmc"]], nIter = 2,
                      runParallel = FALSE, visualise = FALSE,
                      adaptProposal = FALSE)
  expect_s3_class(r2, "StratPosterior")

})

# test time limits
test_that("RunStratModel runs with time limits and terminates early", {
  stratPosterior0a <- RunStratModel(stratObject = stratData0,
                                   stratModel = stratModel0,
                                   nRun = 5,
                                   runParallel = FALSE,
                                   nIter = 5000,
                                   nThin = 5,
                                   saveMCMC = TRUE,
                                   timeLimit = 7/(60^2), # 4.5 seconds,
                                   seed = 1:5,
                                   quiet = TRUE)

  expect_true(stratPosterior0[[c("mcmcSummary", "completedIter")]][[1]] < 5000)

  stratPosterior0b <- RunStratModel(stratObject = stratPosterior0a,
                                    nRun = 5,
                                    runParallel = FALSE,
                                    nIter = 2000,
                                    nThin = 1,
                                    saveMCMC = FALSE,
                                    timeLimit = 4/(60^2), # 3 seconds,
                                    seed = 1:5,
                                    quiet = TRUE,
                                    visualise = FALSE)

  stratPosterior0c <- RunStratModel(stratObject = stratPosterior0b,
                                    runParallel = FALSE,
                                    nIter = 1,
                                    nThin = 5,
                                    saveMCMC = TRUE, seed = 1:5)

  # try a different data set and only 1 run
  stratPosterior2a <- RunStratModel(stratObject = stratData2,
                                    stratModel = stratModel2,
                                    nRun = 1,
                                    runParallel = FALSE,
                                    nIter = 1000,
                                    nThin = 5,
                                    timeLimit = 4/(60^2), # 4 seconds
                                    saveMCMC = TRUE, seed = 1,
                                    quiet = TRUE,
                                    saveChains = c(1,4, 8))

  stratPosterior2b <- RunStratModel(stratObject = stratPosterior2a,
                                    nRun = 1,
                                    runParallel = FALSE,
                                    nIter = 10,
                                    nThin = 8,
                                    timeLimit = 2/(60^2), # 2 seconds
                                    saveMCMC = TRUE, seed = 1,
                                    quiet = TRUE)


  expect_equal(dim(stratPosterior2b[["samples"]])[4], 3)

  skip_if_not_installed("doParallel")
  # time limit with parallel runs
  stratPosterior3a <- RunStratModel(stratObject = stratData3,
                                    stratModel = stratModel3,
                                    nRun = 2,
                                    runParallel = TRUE,
                                    nIter = 5000,
                                    nThin = 3,
                                    timeLimit = 0.5/(60^2), # 2.5 seconds
                                    seed = 1:2,
                                    quiet = TRUE,
                                    saveChains = 1,
                                    visualise = FALSE)
  expect_true(stratPosterior3a[[c("mcmcSummary", "completedIter")]][[1]] < 5000)

})

  # simple test run with more iterations
test_that("RunStratModel works for 100 iterations", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 100,
                      nChains = 3, visualise = FALSE, seed = 1)
  expect_s3_class(r1, "StratPosterior")
})

# test run with different MCMC options - 1
test_that("RunStratModel works with tempering = FALSE and adaptProposal = FALSE", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 50,
                      nChains = 2, tempering = FALSE,
                      adaptProposal = FALSE,
                      visualise = TRUE)
  expect_s3_class(r1, "StratPosterior")
})

# test run with different MCMC options - 1
test_that("RunStratModel works with  adaptTemperatures = FALSE and
different adaptation window and interval", {
  r1 <- RunStratModel(stratData1, stratModel = stratModel1, nRun = 1, nIter = 50,
                      nChains = 2, adaptTemperatures = FALSE,
                      startAdapting = 30, endAdapting = 40,
                      adaptProposalInterval = 3,
                      proposalProbabilityWeights = 1:6,
                      temperatures = c(1,100),
                      visualise = TRUE)
  expect_s3_class(r1, "StratPosterior")
})

# test plotting every iteration in parallel
test_that("RunStratModel works frequent plotting in 8 parallel runs", {
  skip_on_ci()
  # Skip if running via R CMD check
  if (nzchar(Sys.getenv("R_CMD_CHECK"))) {
    skip("Skipping this test during R CMD check")
  }
  r1 <- RunStratModel(stratData0, stratModel = stratModel0,
                      nRun = 8, nIter = 100,
                      nChains = 1, adapt = FALSE,
                      visualise = c(1,1,1),
                      runParallel = TRUE)
  expect_s3_class(r1, "StratPosterior")
})


test_that("StratPosterior() can restore StratPosterior object and can resume
          run from directory", {
  r1a <- RunStratModel(stratData0, stratModel = stratModel0, nRun = 2, nIter = 2,
                       nChains = 3, visualise = FALSE, seed = 1:2,
                       runParallel = FALSE, startAdapting = 4,
                       endAdapting = 10, adaptTemperatures = FALSE,
                       modelDir = tempdir())

  r1b <- StratPosterior(r1a$modelDir, r1a$modelName, stratData0, stratModel0, NULL)
  # check that stratData and stratModel are read from dir
  r1c <- StratPosterior(r1a$modelDir, r1a$modelName)

  expect_equal(r1a, r1b, ignore_attr = TRUE)
  expect_equal(r1b, r1c, ignore_attr = TRUE)

  r1d <- RunStratModel(modelDir = r1a$modelDir, modelName = r1a$modelName, nIter = 3)

  expect_s3_class(r1d, "StratPosterior")

})

test_that(".CheckSeed() throws errors", {
  expect_error(.CheckSeed(1, 2), "seed must")
  expect_error(.CheckSeed(c(TRUE, FALSE), 1), "seed must")
  expect_error(.CheckSeed("a", 1), "seed must")
  expect_error(.CheckSeed("a", 1), "seed must")
  expect_error(.CheckSeed(NULL, 1), "seed must")
})


# ensure results are identical with identical seeds

test_that("RunStratModel behaves consistently with random seeds", {
  test1 <- RunStratModel(stratData0, stratModel0, nIter = 3, seed = 1,
                         visualise = FALSE)
  test2 <- RunStratModel(stratData0, stratModel0, nIter = 3, seed = 1,
                         visualise = FALSE)

  testthat::expect_equal(test1$samples[3, 1, 1, 1],
                         test2$samples[3, 1, 1, 1],
                         tolerance = 0.001)

  skip_if_not_installed("doParallel")
  test3 <- RunStratModel(stratData0, stratModel0, nIter = 3, seed = 1:2,
                         runParallel = TRUE, nRun = 2, visualise = FALSE)

  testthat::expect_equal(test1$samples[3, 1, 1, 1],
                         test3$samples[3, 1, 1, 1],
                         tolerance = 0.001)
})


# test 7 (using ties):
test_that("RunStratModel still works with legacy test data 7", {

dat7 <- StratData(
  signal = testthat::test_path("testdata", "test-7", "test-7-signal.csv"),
  ties = testthat::test_path("testdata", "test-7", "test-7-date-high-sd.csv"))

priors <- structure(list(
  `alpha_site 1` = NormalPrior(mean = 49.7, sd = 1),
  `alpha_site 2` = UniformPrior(min = -120, max = 120),
  `gammaLog_site 1` = NormalPrior(mean = 0, sd = 0.05),
  `gammaLog_site 2` = NormalPrior(mean = 0, sd = 1)
),
class = c("StratPrior", "list"))

set.seed(7)
skip_if_not_installed("doParallel")
test_7_result_1b <- RunStratModel(
  stratObject = dat7, alignmentScale = "age", sedModel = "site",
  nChains = 8, nIter = 20, nThin = 5,
  nKnots = 15, priors = priors, nRun = 2, runParallel = TRUE,
  seed = 1:2, sigmaFixed = TRUE, visualise = interactive() * 50,
  quiet = FALSE, flexibleKnots = TRUE
)

estimates <- summary(test_7_result_1b)

nAln <- estimates[[c("general", "overallAlignments")]]
correctAlignment1 <-
  abs(vapply(
    seq_len(nAln),
    function(a) estimates[[a]][["summary"]]["alpha_site 2", "mean"],
    numeric(1)
  ) - 83) < 8

correctAlignment2 <-
  abs(vapply(
    seq_len(nAln),
    function(a) estimates[[a]][["summary"]]["alpha_site 2", "mean"],
    numeric(1)
  ) - 35) < 8


# at least one correct alignment:
expect_gte(sum(correctAlignment1,correctAlignment2), 1)
})

test_that(".RemoveResidualPlotFiles works", {
  testDir <- tempfile("testDir")
  dir.create(testDir)
  on.exit(unlink(testDir))
  modelName <- "testModel"
  path1 <- file.path(testDir, paste0(modelName,"_plot_samples_run_2.rds"))
  path2 <- file.path(testDir, "plot_run_2_sig_2.png")
  path3 <- file.path(testDir, "plot_run_1_sig_1.png")
  path4 <- file.path(testDir, "plot_parameter_posterior.png")
  path5 <- file.path(testDir, "plot_parameter_alpha_site1.png")
  saveRDS(1, file = path1)
  png(path2)
  plot.new()
  dev.off()
  png(path3)
  plot.new()
  dev.off()
  png(path4)
  plot.new()
  dev.off()
  png(path5)
  plot.new()
  dev.off()
  Sys.sleep(0.025) # delay to allow finishing file writing
  expect_true(file.exists(path1))
  expect_true(file.exists(path2))
  expect_true(file.exists(path3))
  expect_true(file.exists(path4))
  expect_true(file.exists(path5))

  parametersToPlot <- c("posterior", "alpha_site1")
  # remove potential residual plot files from previous run (on.exit deletion
  # doesn't always work on Mac):
  StratoBayes:::.RemoveResidualPlotFiles(saveVisualiseDir = testDir, modelDir = testDir,
                                         modelName = modelName, nRun = 2,
                                         sigIndices = 1:2, parameters =
                                           parametersToPlot)

  expect_true(all(c(file.exists(path1), file.exists(path2), file.exists(path3),
                    file.exists(path4), file.exists(path5)) == FALSE))

})
