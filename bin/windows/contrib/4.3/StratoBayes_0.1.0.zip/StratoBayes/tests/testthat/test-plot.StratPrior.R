test_that("Multiple priors are plotted with plot.StratPrior", {

  priors <- structure(list(
    `alpha_site_2` = UniformPrior(min = -60, max = 60),
    `gammaLog_site_2` = NormalPrior(mean = 0, sd = log(2))),
    class = c("StratPrior", "list"))

  discard <- tempfile()
  png(filename = discard)
  on.exit(unlink(discard))
  # expect_warning(
  #   plot(priors, 1:2),
  #   "unnamed arguments"
  # )
  dev.off()

  skip_if_not_installed("vdiffr")
  if (interactive()) {
    plot(priors, parameters = 1:2)
  }

  vdiffr::expect_doppelganger("multiple-priors",
                              function() plot(priors, parameters = 1:2))
})

  test_that("plot.StratPrior works with stratPrior1", {
    vdiffr::expect_doppelganger("plot.stratPrior - 1", function() {
      plot(stratPrior1, col = "grey",
           parameters = "alpha_site_2")
    })})

  test_that("plot.StratPrior works with stratPrior2", {
    vdiffr::expect_doppelganger("plot.stratPrior - 2", function() {
      plot(stratPrior2, alpha = .25, overridePar = TRUE,
           parameters = c("alpha_site3", 5, 1, 6, 5, "alpha", 6, "gap", 3))
    })})

  test_that("plot.StratPrior works with non-log gamma and prior from stratPosterior object", {
    vdiffr::expect_doppelganger("plot.stratPrior - 3", function() {
      plot(stratPosterior2$model$priors, log = FALSE, overridePar = F, parameters = 5)
    })})

  test_that("plot.StratPrior works with fixed prior", {
    vdiffr::expect_doppelganger("plot.stratPrior - 4", function() {
      plot(stratPrior3, log = FALSE, parameters = "all")
    })})

  test_that("plot.StratPrior works with fixed prior - 2", {
    vdiffr::expect_doppelganger("plot.stratPrior - 5", function() {
      plot(stratPrior3, log = FALSE, parameters = 2)
    })})

  test_that("plot.StratPrior works with uniform non-log gamma", {
    vdiffr::expect_doppelganger("plot.stratPrior - 6", function() {
  plot(structure(list(
    "alpha_site2" = UniformPrior(min = -8, max = 8),
    "gammaLog_site2" = UniformPrior(min = log(1/4), max = log(4))),
    class = c("StratPrior", "list")), log = F, parameters = "gamma", overridePar = F)
    })
  })

  test_that("plot.StratPrior produces margin error message", {
    png(filename = tempfile(), width = 50, height = 50)
    expect_error({plot.StratPrior(stratPrior0)},
                 regexp = "The plot window is too small for the specified margins")
    dev.off()
  })
