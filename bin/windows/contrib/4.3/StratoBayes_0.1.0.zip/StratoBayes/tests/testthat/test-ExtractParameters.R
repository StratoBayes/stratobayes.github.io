test_that("ExtractParameters works", {
  # errors
  expect_error(ExtractParameters(stratPosterior1,
                                   selectRows = list(NULL, NULL, NULL)),
                 "Parameter selection")
  expect_error(ExtractParameters(stratPosterior1,
                                   runs = 4),
                 "runSelect needs")

  # example
  params <- ExtractParameters(stratPosterior1)
  expect_s3_class(params, "data.frame")
  expect_equal(dim(params), c(300, 4))
})

test_that("'likelihood' works when likelihood ties don't exist", {
  params <-  ExtractParameters(stratPosterior1, parameters = "likelihood")
  expect_s3_class(params, "data.frame")

  params <-  ExtractParameters(stratPosterior1, parameters = "all")
  expect_equal(ncol(params), 28)

  params <-  ExtractParameters(stratPosterior1)
  expect_equal(ncol(params), 4)
})

test_that("selectRows can be a vector or a list", {
  expect_equal(dim(ExtractParameters(stratPosterior1, selectRows = 100:201)),
               c(102 * 3, 4))
  expect_equal(ExtractParameters(stratPosterior1, runs = 2:3,
                                 parameters = "alpha_site_3",
                                 selectRows = 100:102)[, 1],
               c(stratPosterior1$samples[100:102,2,2:3,1]),
               tolerance = 0.01)
  expect_equal(dim(ExtractParameters(stratPosterior1, runs = 2,
                                     selectRows = list(100:201))),
               c(102, 4))
  expect_equal(ExtractParameters(stratPosterior1, runs = c(3, 1),
                                 parameters = "alpha_site_3",
                                 selectRows = list(102:101, 100:101))[, 1],
               as.numeric(c(stratPosterior1$samples[102:101,2,3,1], stratPosterior1$samples[100:101,2,1,1])),
               tolerance = 0.05)
})


test_that("ExtractParameters works with new cluster object and
          iterations before burnIn", {
            # works only with this specific generation of stratPosterior1
            clustNew <- Cluster(stratPosterior1, iterations = 500)
              expect_equal(
                class(ExtractParameters(stratPosterior1,
                        stratCluster = clustNew,
                        alignment = 1)[,2]), "numeric")
})
