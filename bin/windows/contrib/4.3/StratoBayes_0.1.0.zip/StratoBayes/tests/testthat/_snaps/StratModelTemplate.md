# StratModelTemplate works - 01

    Code
      StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s")
    Output
      
      priors <- structure(list(
        "alpha_site_2" = UniformPrior(min = , max = ),
        "alpha_site_3" = UniformPrior(min = , max = ),
        "gammaLog_site_2" = NormalPrior(mean = , sd = ),
        "gammaLog_site_3" = NormalPrior(mean = , sd = )),
        class = c("StratPrior", "list"))
      
      model <- StratModel(stratData = stratData1,
                          priors = priors,
                          alignmentScale = "height",
                          sedModel = "site",
                          alphaPosition = "middle",
                          nKnots = 25)
      
      result <- RunStratModel(stratObject = stratData1,
                              stratModel = model,
                              nRun = 1,
                              nIter = 1000)

# StratModelTemplate works - 02

    Code
      StratModelTemplate(stratData1, alignmentScale = "height", sedModel = "s x p",
        gammaLog = "normal", zetaLog = "truncated normal", gap = "truncated log normal")
    Output
      
      priors <- structure(list(
        "alpha_site_2" = UniformPrior(min = , max = ),
        "alpha_site_3" = UniformPrior(min = , max = ),
        "gammaLog_1" = NormalPrior(mean = , sd = ),
        "zetaLog_site_3" = TruncNormalPrior(mean = , sd = , lower = , upper = )),
        class = c("StratPrior", "list"))
      
      model <- StratModel(stratData = stratData1,
                          priors = priors,
                          alignmentScale = "height",
                          sedModel = "site x partition",
                          alphaPosition = "middle",
                          nKnots = 25)
      
      result <- RunStratModel(stratObject = stratData1,
                              stratModel = model,
                              nRun = 1,
                              nIter = 1000)

# StratModelTemplate works - 03

    Code
      StratModelTemplate(stratData2, alignmentScale = "age", sedModel = "s, p",
        alphaPosition = c(100, "middle", "bottom"))
    Output
      
      priors <- structure(list(
        "alpha_site1" = UniformPrior(min = , max = ),
        "alpha_site2" = UniformPrior(min = , max = ),
        "alpha_site3" = UniformPrior(min = , max = ),
        "gammaLog_part 1.1_site1" = NormalPrior(mean = , sd = ),
        "gammaLog_part 2.1_site2" = NormalPrior(mean = , sd = ),
        "gammaLog_part 2.2_site2" = NormalPrior(mean = , sd = ),
        "gammaLog_part 3.1_site3" = NormalPrior(mean = , sd = ),
        "gap_site2_1" = ExponentialPrior(rate = )),
        class = c("StratPrior", "list"))
      
      model <- StratModel(stratData = stratData2,
                          priors = priors,
                          alignmentScale = "age",
                          sedModel = "site, partition",
                          alphaPosition = c(100, "middle", "bottom")
                          nKnots = 25)
      
      result <- RunStratModel(stratObject = stratData2,
                              stratModel = model,
                              nRun = 1,
                              nIter = 1000)

# StratModelTemplate works - 04

    Code
      StratModelTemplate(stratData2, alignmentScale = "age", sedModel = "s, p",
        alpha = "fixed", gap = "log normal", alphaPosition = c(100, "middle",
          "bottom"))
    Output
      
      priors <- structure(list(
        "alpha_site1" = Fixed(value = ),
        "alpha_site2" = Fixed(value = ),
        "alpha_site3" = Fixed(value = ),
        "gammaLog_part 1.1_site1" = NormalPrior(mean = , sd = ),
        "gammaLog_part 2.1_site2" = NormalPrior(mean = , sd = ),
        "gammaLog_part 2.2_site2" = NormalPrior(mean = , sd = ),
        "gammaLog_part 3.1_site3" = NormalPrior(mean = , sd = ),
        "gap_site2_1" = LogNormalPrior(meanlog = , sdlog = )),
        class = c("StratPrior", "list"))
      
      model <- StratModel(stratData = stratData2,
                          priors = priors,
                          alignmentScale = "age",
                          sedModel = "site, partition",
                          alphaPosition = c(100, "middle", "bottom")
                          nKnots = 25)
      
      result <- RunStratModel(stratObject = stratData2,
                              stratModel = model,
                              nRun = 1,
                              nIter = 1000)

