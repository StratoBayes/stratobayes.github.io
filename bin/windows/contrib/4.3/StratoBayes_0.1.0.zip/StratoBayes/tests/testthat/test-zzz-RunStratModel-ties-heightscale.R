test_that("ties work on height scale", {

  skip_on_cran() # slow

  set.seed(0)
  n1 <- 100
  x1 <- seq(0, 4 * pi, length.out = n1)
  y1 <- sin(x1) + rnorm(n1, 0, 0.1)
  n2 <- 25
  x2 <- seq(1/2 * pi, pi, length.out = n2)
  y2 <- sin(x2) + rnorm(n2, 0, 0.1)
  x2 <- x2 * 3/2
  testD <- data.frame(height = c(x1, x2),
                      value = c(y1, y2),
                      site = c(rep("a", n1), rep("b", n2)))
  stratD <- StratData(testD)
  if (interactive())  {
    plot(stratD)
  }

  #StratModelTemplate(stratD, "h", "s", "m")
  priors <- structure(list(
    "alpha_b" = UniformPrior(min = -1/2 * pi, max = (4 + 1/2) * pi),
    "gammaLog_b" = NormalPrior(mean = 0, sd = 0.5)),
    class = c("StratPrior", "list"))

  model <- StratModel(stratData = stratD,
                      priors = priors,
                      alignmentScale = "height",
                      sedModel = "site",
                      alphaPosition = "middle",
                      nKnots = 12,
                      overlapPenalty = TRUE,
                      sigmaFixed = TRUE)

  r1 <- RunStratModel(stratObject = stratD,
                      stratModel = model,
                      nRun = 2,
                      nIter = 150,
                      runParallel = requireNamespace("doParallel", quietly = TRUE),
                      visualise = FALSE,
                      seed = 1:2)

  if (interactive())  {
    plot(r1, alignment = "all")
    TracePlot(r1, colourBy = "alignment", type = "o",
              parameters = c(1,"posterior"))
  }

  estimates <- summary(r1, alignment = 1)

  # Two possible expected values
  expected_value_1 <- (2 + 3/4) * pi
  expected_value_2 <- (3/4) * pi

  # Get the actual estimate value
  estimate_value <- estimates$alignment1$summary["alpha_b", "50%"]

  # Check if the estimate is within the tolerance range of either expected value
  test_result <- (abs(estimate_value - expected_value_1) <= 1/4) ||
    (abs(estimate_value - expected_value_2) <= 1/4)

  # Use test_result in expect_true
  expect_true(test_result)


  # add tie to pull to peak 1 :
  ties <- data.frame(height = 3/2 * 1/2 * pi ,
                     mean = 3/4 * pi,
                     sd = 1/2,
                     site = "b")
  stratD <- StratData(testD, ties = ties)

  model <- StratModel(stratData = stratD,
                      priors = priors,
                      alignmentScale = "height",
                      sedModel = "site",
                      alphaPosition = "middle",
                      nKnots = 12,
                      overlapPenalty = TRUE,
                      sigmaFixed = TRUE)

  r1 <- RunStratModel(stratObject = stratD,
                      stratModel = model,
                      nRun = 2,
                      nIter = 100,
                      runParallel = requireNamespace("doParallel", quietly = TRUE),
                      visualise = FALSE,
                      seed = 1:2)

  if (interactive())  {
    plot(r1, separateSites = FALSE)
    TracePlot(r1, colourBy = "alignment", type = "o",
              parameters = c(1,"posterior"))
  }

  estimates <- summary(r1, alignment = 1)

  # relative tolerance:
  expect_equal(estimates$alignment1$summary["alpha_b","50%"],
               3 * pi / 4, tolerance = 0.15)

})
