test_that("hist.StratPosterior works", {
  vdiffr::expect_doppelganger("hist 1", function() {
    hist(stratPosterior1)
  })})

test_that("hist.StratPosterior works with colour for prior", {
  vdiffr::expect_doppelganger("hist 2", function() {
    hist(stratPosterior1, prior = rgb(0,.5,.8,.3), alignment = 1,
         iterations = 4000:5000)
  })})

test_that("hist.StratPosterior works colourBy = 'none'", {
  vdiffr::expect_doppelganger("hist 3", function() {
    hist(stratPosterior1, colourBy = "none")
  })})

test_that("hist.StratPosterior works colourBy = 'run'", {
  vdiffr::expect_doppelganger("hist 4", function() {
    hist(stratPosterior1, colourBy = "run")
  })})

test_that("hist.StratPosterior works with three parameters", {
  vdiffr::expect_doppelganger("hist 5", function() {
    hist(stratPosterior1, parameters = "parameters")
  })})


  test_that("hist.StratPosterior works without Prior", {
    vdiffr::expect_doppelganger("hist 6", function() {
      hist(stratPosterior1, prior = F, parameters = c("posterior", 2), colourBy = "run",
           colourScale = "Plasma", burnIn = .9)
    })})

  test_that("hist.StratPosterior works without Prior 2", {
    vdiffr::expect_doppelganger("hist 7", function() {
      hist(stratPosterior2, prior = F, freq = T,
           parameters = c(3, "prior"), colourBy = "none",
           ylab = "something else", col = "dodgerblue")
    })})

  test_that("hist.StratPosterior works with three parameters", {
    vdiffr::expect_doppelganger("hist 8", function() {
      hist(stratPosterior2, colourBy = "alignment")
    })})

  test_that("hist.StratPosterior works with fixed parameter - run", {
    vdiffr::expect_doppelganger("hist 9", function() {
      hist(stratPosterior3, colourBy = "run", parameters = 2:1)
    })})

  test_that("hist.StratPosterior works with fixed parameter - alignment", {
    vdiffr::expect_doppelganger("hist 10", function() {
      hist(stratPosterior3, colourBy = "alignment", parameters = 2)
    })})

  test_that("hist.StratPosterior works with fixed parameter - none", {
    vdiffr::expect_doppelganger("hist 11", function() {
      hist(stratPosterior3, colourBy = "none", parameters = 1:3)
    })})

  test_that("hist.StratPosterior works with new cluster object and
          iterations before burnIn", {
            set.seed(12)
            clustNew <- Cluster(stratPosterior1, iterations = 100:200)

            vdiffr::expect_doppelganger("hist 12", function() {
              hist(stratPosterior1, colourBy = "alignment",
                          stratCluster = clustNew, type = "o")
            })})


  test_that("hist.StratPosterior produces margin error message", {
    png(filename = tempfile(), width = 50, height = 50)
    expect_error({hist(stratPosterior2, colourBy = "al")},
                 regexp = "The plot window is too small for the specified margins")
    dev.off()
  })
