test_that("ScatterPlot works", {
  set.seed(1)
  vdiffr::expect_doppelganger("ScatterPlot 1", function() {
    ScatterPlot(stratPosterior1)
  })})

test_that("ScatterPlot works with custom colours", {
  vdiffr::expect_doppelganger("ScatterPlot 2", function() {

    ScatterPlot(stratPosterior2, colourBy = "none", parameters = 2:3,
                type = "o", alpha = 1,
                alignment = "all", pch = 21, bg = "red", col = "gold")
  })})

test_that("ScatterPlot works with iterations passed as list and maxSamples", {
  vdiffr::expect_doppelganger("ScatterPlot 3", function() {
    set.seed(1)
    ScatterPlot(stratPosterior2, colourBy = "al",
                parameters = "gamma",
                runs = c(2,3), alpha = 1, iterations = list(1:2500,1:2500,NULL,NULL),
                maxSamples = 100)
  })})

test_that("ScatterPlot works with colourBy = 'run'", {
  vdiffr::expect_doppelganger("ScatterPlot 4", function() {
    set.seed(1)
    ScatterPlot(stratPosterior2, colourBy = "run",
                type = "o", iterations = 4000:5000,
                parameters = 3:4)
  })})


test_that("ScatterPlot works with type = 'l'", {
  vdiffr::expect_doppelganger("ScatterPlot 5", function() {
    set.seed(1)
    ScatterPlot(stratPosterior3, colourBy = "alignment",
                type = "o", parameters = c(1,3))
  })})


test_that("ScatterPlot with new cluster object and iterations before burnIn", {
  set.seed(6)
  clustNew <- Cluster(stratPosterior1, iterations = 100:200)

  vdiffr::expect_doppelganger("ScatterPlot 6", function() {
    ScatterPlot(stratPosterior1, colourBy = "alignment",
                stratCluster = clustNew, type = "o")
  })
})


test_that("ScatterPlot produces margin error message", {
  tmpFile <- tempfile()
  png(filename = tmpFile, width = 50, height = 50)
  on.exit(unlink(tmpFile))
  expect_error({ScatterPlot(stratPosterior2)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
})
