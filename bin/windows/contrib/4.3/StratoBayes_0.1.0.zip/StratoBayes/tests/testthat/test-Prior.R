test_that("UniformPrior works", {

  expect_error(UniformPrior(2,1), "min needs to be < max")

  expect_s3_class(UniformPrior(1,2), "Prior")

})

test_that("Fixed works", {

  expect_error(Fixed(2,1), "unused argument")

  expect_s3_class(Fixed(1), "Prior")

})

test_that("ExponentialPrior works", {

  expect_error(ExponentialPrior(-1), "rate needs to be")

  expect_s3_class(ExponentialPrior(1), "Prior")

})

test_that("NormalPrior works", {

  expect_error(NormalPrior(-1, 0), "sd needs to be")

  expect_s3_class(NormalPrior(2,2), "Prior")

})

test_that("LogNormalPrior works", {

  expect_error(LogNormalPrior(-2, -1), "sdlog needs to be")

  expect_s3_class(LogNormalPrior(-2,2), "Prior")

})

test_that("TruncNormalPrior works", {

  expect_error(TruncNormalPrior(0, 0, 1, 2), "sd needs to be")
  expect_error(TruncNormalPrior(0, 1, 3, 2), "lower needs to be")

  expect_s3_class(TruncNormalPrior(0,1,2,3), "Prior")

})

test_that("TruncLogNormalPrior works", {
  expect_error(TruncLogNormalPrior(0, 0, 1, 2), "sdlog needs to be")
  expect_error(TruncLogNormalPrior(0, 1, 3, 2), "lower needs to be")

  expect_s3_class(TruncLogNormalPrior(0,1,2,3), "Prior")

})

test_that("NormalToLogNormal works", {

  expect_error(NormalToLogNormal(-1,0),
               "mu and sigma must be positive")

  a <- 0.5
  b <- 0.3
  abTransformed <- NormalToLogNormal(a, b)
  samples <- rlnorm(10000, abTransformed$mu, abTransformed$sigma)

  expect_equal(a, mean(samples), tolerance = 0.1)
  expect_equal(b, sd(samples), tolerance = 0.1)

  a <- 21
  b <- 2
  abTransformed <- NormalToLogNormal(a, b)
  samples <- rlnorm(10000, abTransformed$mu, abTransformed$sigma)

  expect_equal(a, mean(samples), tolerance = 0.1)
  expect_equal(b, sd(samples), tolerance = 0.1)
  }

          )
