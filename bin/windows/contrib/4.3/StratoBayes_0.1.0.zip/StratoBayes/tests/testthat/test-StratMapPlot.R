
test_that("StratMapPlot works", {
  expect_error(StratMapPlot(1, 2, 2), "stratObject needs to be")

  set.seed(1)
  vdiffr::expect_doppelganger("StratMapPlot 1", function() {
    StratMapPlot(stratPosterior1)
  })})

test_that("StratMapPlot works with custom settings", {
  vdiffr::expect_doppelganger("StratMapPlot 2", function() {

    StratMapPlot(stratPosterior2, alignment = 2, sites = 3:1,
             burnIn = 0.95, tiesColour = "orange", col = rgb(0.5,0,0,1),
             lwd = 2)
  })})

test_that("StratMapPlot works on depth scale", {
  vdiffr::expect_doppelganger("StratMapPlot 3", function() {

    StratMapPlot(stratPosterior3, xlab = "depth (m) at 2")
  })})

test_that("StratMapPlot can plot prior", {
  vdiffr::expect_doppelganger("StratMapPlot 4", function() {
    set.seed(1)
    StratMapPlot(stratModel0, stratData = stratData0, maxSamples = 100)
  })})

test_that("StratMapPlot can plot posterior and prior", {
  vdiffr::expect_doppelganger("StratMapPlot 5", function() {

    set.seed(1)
    StratMapPlot(stratPosterior2, prior = TRUE, col = 2:3, tiesColour = 4,
                 sites = 1:2, pch = 2, cex = 2, lwd = 2)
  })})


test_that("StratMapPlot produces margin error message", {
  png(filename = tempfile(), width = 50, height = 50)
  expect_error({StratMapPlot(stratPosterior2)},
               regexp = "The plot window is too small for the specified margins")
  dev.off()
})
