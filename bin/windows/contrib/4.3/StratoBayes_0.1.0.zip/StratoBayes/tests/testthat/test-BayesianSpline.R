test_that("BayesianSpline() works with custom knots", {
   set.seed(1)
   x <- runif(100, 0, 12)
   y <- 0.5 * x + sin(x) + rnorm(100)

   testSpline <- BayesianSpline(x, y, knots = seq(0, 12, 0.25))

   burnin <- floor(0.5 * nrow(testSpline$beta))

   Bmat  <- splines::splineDesign(
      testSpline$model$splineBase$ext_knots, c(0, 4, 12), sparse = FALSE)

   mean_beta <- apply(testSpline$beta[(burnin + 1):nrow(testSpline$beta), ],
                       2, mean)

   pred <- round(.MatrixVectorMult(Bmat, mean_beta), 3)

   expect_equal(pred, c(0.575, 1.299, 5.139), tolerance = 0.01)

   predSp1 <- PredictSpline(testSpline)
   expect_equal(nrow(predSp1), 49)

   predSp2 <- PredictSpline(testSpline, at = c(2, 9), burnIn = 80)

   expect_equal(predSp2$mu, c(1.4, 4.7), tolerance = 0.2)
})
