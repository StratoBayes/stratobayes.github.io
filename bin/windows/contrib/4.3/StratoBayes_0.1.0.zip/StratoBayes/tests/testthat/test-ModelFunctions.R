{ # Initialize
  expectSpecificVector <- function(object, len, type, info = NULL) {
    expect_equal(class(object), type)
    expect_length(object, len)
    expect_true(all(!is.na(object)), info = paste(deparse(substitute(object)),
                                                  "contains NA values"))
  }

  set.seed(0)
  testDataMulti <- .GenerateTestData("multi", version = "gap-names-3-sites-dates")
  tmulti <- StratData(testDataMulti$signal, parts = testDataMulti$parts,
                      ties = testDataMulti$ties,
                      signalColumn = c("a", "b"), zColumn = "Hight",
                      siteColumn = "SIT")
  #StratModelTemplate(tmulti, alignmentScale = "age", sedModel = "s", alphaPosition = "b")
  priorsm <- structure(list(
      "alpha_site1" = UniformPrior(min  = 10, max  = 60),
      "alpha_site2" = UniformPrior(min  = -10, max  = 60),
      "alpha_site3" = UniformPrior(min  = -10, max  = 60),
      "gammaLog_site1" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_site2" = NormalPrior(mean  = 1, sd  = 1),
      "gammaLog_site3" = NormalPrior(mean  = 1, sd  = 1),
      "gap_site2_1" = ExponentialPrior(rate  = 0.1)),
    class = c("list", "StratPrior"))

  model <- StratModel(tmulti, priorsm,
                      alignmentScale = "age",
                      sedModel = "site",
                      alphaPosition = "bottom")
  mcmc <- StratMCMC(model, nIter = 10, nChains = 2)
}

# t3 <- RunStratModel(tmulti, priors = priorsm, sigmaFixed = FALSE, nIter = 200,  visualise = 50,
#                     gibbsPriors = list(aSigma = 0.01, bSigma = 100, aLambda = 1, bLambda = 1))
# t4 <- RunStratModel(tmulti, priors = priorsm, sigmaFixed = TRUE, nIter = 200,  visualise = 50,
#                     gibbsPriors = list(aSigma = 1, bSigma = 1, aLambda = 1, bLambda = 1))
## Testing the components of .GenerateInitialState

test_that("Initialization successful", {
  # This behaviour is not tested in test-Stratdata.R
  # Worth checking here.
  expect_equal(lengths(tmulti[[c("signalAttr", "signalGapSectBindSepSignal")]]),
               c(a = 3, b = 3))
})

test_that(".GenerateValidProposal works", {
  stateNew <- .GenerateValidProposal(tmulti, model, mcmc, stateOld = NULL,
                                     ProposeMetro = .MetroPriorSample,
                                     initialState = TRUE, chain = 1)


  expectSpecificVector(stateNew$metro$parameters, length(model$parametersNames), "numeric")
  expectSpecificVector(stateNew$age$ageRange, 2, "numeric")

  for (s in seq_along(stateNew$age$signal)) {
    expectSpecificVector(stateNew$age$signal[[s]], tmulti$signalAttr$N[s], "numeric")
    expectSpecificVector(stateNew$age$ties[[s]], tmulti$tiesAttr$tiesN[s], "numeric")
  }

  for (m in seq_along(tmulti$signalAttr$signalNames)) {
    expectSpecificVector(stateNew$age$signalSectionOverlap[[m]], tmulti$signalAttr$nPerSignal[m], "integer")
  }
})


test_that(".FlexibleKnotsUpdateDB works", {

  stateNew <- .GenerateValidProposal(tmulti, model, mcmc, stateOld = NULL, ProposeMetro = .MetroPriorSample,
                                     initialState = TRUE, chain = 1)
  stateNew <- .FlexibleKnotsUpdateDB(tmulti, model, stateNew)

  expect_true("matrix" %in% class(stateNew$spline$D))
  expect_false(any(is.na(stateNew$spline$D)))
  expect_true("matrix" %in% class(stateNew$metro$B[[1]]))
  expect_true("matrix" %in% class(stateNew$metro$B[[2]]))
  expect_false(any(is.na(stateNew$metro$B[[2]])))
  expect_false(any(is.na(stateNew$metro$B[[2]])))
})


test_that(".InitializeGibbs works", {

  stateNew <- .GenerateValidProposal(tmulti, model, mcmc, stateOld = NULL, ProposeMetro = .MetroPriorSample,
                                     initialState = TRUE, chain = 1)
  stateNew <- .FlexibleKnotsUpdateDB(tmulti, model, stateNew)

  stateNew <- .InitializeGibbs(tmulti, model, stateNew)

  expectSpecificVector(stateNew$gibbs$lambda, 2, "numeric")
  expectSpecificVector(stateNew$gibbs$beta[[1]], model$splineBase$num_basis, "numeric")
  expectSpecificVector(stateNew$gibbs$beta[[2]], model$splineBase$num_basis, "numeric")
  expectSpecificVector(stateNew$gibbs$sigma[[1]], 1, "numeric")
  expectSpecificVector(stateNew$gibbs$sigma[[2]], 1, "numeric")

})

test_that(".UpdateHtBy works", {

  stateNew <- .GenerateValidProposal(tmulti, model, mcmc, stateOld = NULL, ProposeMetro = .MetroPriorSample,
                                     initialState = TRUE, chain = 1)
  stateNew <- .FlexibleKnotsUpdateDB(tmulti, model, stateNew)

  stateNew <- .InitializeGibbs(tmulti, model, stateNew)

  stateNew <- .UpdateHtBy(tmulti, stateNew)

  expect_true("matrix" %in% class(stateNew$metro$H[[1]]))
  expect_false(any(is.na(stateNew$metro$H[[1]])))
  expect_equal(dim(stateNew$metro$H[[1]]), rep(model$splineBase$num_basis,2))
  expect_true("matrix" %in% class(stateNew$metro$H[[2]]))
  expect_false(any(is.na(stateNew$metro$H[[2]])))
  expect_equal(dim(stateNew$metro$H[[2]]), rep(model$splineBase$num_basis,2))
  expectSpecificVector(stateNew$metro$tBy[[1]], model$splineBase$num_basis, "numeric")
  expectSpecificVector(stateNew$metro$tBy[[2]], model$splineBase$num_basis, "numeric")
})


test_that(".LogLikTies and .LogPost works", {
  stateNew <- .GenerateValidProposal(tmulti, model, mcmc, stateOld = NULL, ProposeMetro = .MetroPriorSample,
                                     initialState = TRUE, chain = 1)
  stateNew <- .FlexibleKnotsUpdateDB(tmulti, model, stateNew)

  stateNew <- .InitializeGibbs(tmulti, model, stateNew)

  stateNew <- .UpdateHtBy(tmulti, stateNew)

  logLikTies <- .LogLikTies(tmulti, model, stateNew)
  expectSpecificVector(logLikTies, 1, "numeric")

  logPost <- .LogPost(tmulti, model, stateNew)
  expectSpecificVector(logPost, 4, "numeric")

})

test_that(".GenerateInitialState works", {
  state <- .GenerateInitialState(tmulti, model, mcmc, 1)
  expectSpecificVector(state$metro$logPost, 1, "numeric")
})

test_that(".UpdateState works", {
  state <- .GenerateInitialState(tmulti, model, mcmc, 1)
  stateNew <- .UpdateState(tmulti, model, mcmc, state, 1)

  expectSpecificVector(   c(state$metro$logPostOld,
                            state$metro$logPostNew,
                            state$metro$logPost), 3, "numeric")
  expectSpecificVector(   c(stateNew$metro$logPostOld,
                            stateNew$metro$logPostNew,
                            stateNew$metro$logPost), 3, "numeric")
  })

